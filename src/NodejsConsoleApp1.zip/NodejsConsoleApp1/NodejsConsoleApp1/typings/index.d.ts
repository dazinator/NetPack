/// <reference path="globals/mock-fs/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
